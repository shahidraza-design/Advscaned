"""
export.py — compile the questions a teacher ticked into a new paper.

Builds Markdown (text + images + LaTeX math), then Pandoc converts it to:
  * .docx — fully editable in Word / Google Docs, math becomes real Word equations
  * .pdf  — via a LaTeX engine (xelatex) if installed
"""
from __future__ import annotations

import subprocess
from pathlib import Path


def build_markdown(data: dict, selected_ids: list[str], title: str = "Question Paper",
                   instructions: str = "", renumber: bool = True) -> str:
    by_id = {q["id"]: q for q in data["questions"]}
    lines = [f"# {title}", ""]
    if instructions:
        lines += [f"*{instructions}*", ""]

    for n, qid in enumerate(selected_ids, 1):
        q = by_id[qid]
        num = n if renumber else q["number"]
        above = [a for a in q["assets"] if a["placement"] == "above"]
        rest = [a for a in q["assets"] if a["placement"] != "above"]

        for a in above:
            lines += _asset_md(a)
        lines += [f"**{num}.** {q['text']}", ""]
        for p in q.get("parts", []):
            lines += [f"    {p}", ""]
        for a in rest:
            lines += _asset_md(a)
    return "\n".join(lines)


def _asset_md(a: dict) -> list[str]:
    if a["kind"] == "formula" and a.get("latex"):
        return [f"$${a['latex']}$$", ""]
    if a.get("image"):
        width = "40%" if a["placement"] == "right" else "60%"
        cap = a.get("caption") or ""
        return [f"![{cap}]({a['image']}){{width={width}}}", ""]
    return []


def compile_paper(data: dict, selected_ids: list[str], asset_dir: str | Path,
                  out_path: str | Path, **kw) -> Path:
    asset_dir, out_path = Path(asset_dir), Path(out_path)
    md = build_markdown(data, selected_ids, **kw)
    md_file = out_path.with_suffix(".md")
    md_file.write_text(md, encoding="utf-8")

    cmd = ["pandoc", str(md_file), "-o", str(out_path),
           f"--resource-path={asset_dir}"]
    if out_path.suffix == ".pdf":
        cmd += ["--pdf-engine=xelatex", "-V", "geometry:a4paper,margin=2cm"]
    subprocess.run(cmd, check=True)
    return out_path
