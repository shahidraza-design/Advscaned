# Question Paper Builder — backend (free & open source)

Photo of a textbook page → question "packages" (question + its diagrams/formulas)
→ teacher ticks questions → editable Word file or PDF.

## Files
| File | What it does |
|---|---|
| `pairing.py` | Reading order + pairs every diagram/formula/table with its question. No AI needed — run `python pairing.py` for a demo. |
| `pipeline.py` | Page photo → blocks, using DocLayout-YOLO (layout), Tesseract (text), pix2tex (math → LaTeX). |
| `export.py` | Ticked questions → Markdown → Pandoc → `.docx` (real Word equations) or `.pdf`. |
| `app.py` | FastAPI server the mobile app calls. |

## How pairing decides (strongest rule first)
1. **Caption reference** – caption "Fig. 4.4" + a question that says "Fig. 4.4" → that question.
2. **Side by side** – diagram beside a question's text on the page → that question, shown on the right.
3. **Formulas** – belong to the question they sit inside.
4. **Before vs after** – "…figure **below**" → previous question; "…circuit **above**" → next question;
   otherwise the nearest previous question, with lower confidence.

Every pairing gets a confidence score and a reason. Anything under 0.7 is flagged
`needs_review` so the app can ask the teacher to confirm it.

## Setup (Ubuntu / WSL)
```bash
sudo apt install tesseract-ocr tesseract-ocr-hin tesseract-ocr-ben pandoc texlive-xetex
pip install -r requirements.txt
OCR_LANG=eng uvicorn app:app --host 0.0.0.0 --port 8000
# then open http://localhost:8000/docs
```
First run downloads the free model weights (a few hundred MB).

## Known limits (next steps)
- Math *inside* a sentence: DocLayout-YOLO only finds standalone formulas. For inline
  math, swap `pipeline.py` for PaddleOCR PP-StructureV3 or MinerU, which detect it.
- One diagram shared by several questions ("Use the figure for Q4–6") goes to the
  first; the teacher can copy it on the review screen.
- Handwriting and very low-light photos reduce accuracy — the review screen is essential.
