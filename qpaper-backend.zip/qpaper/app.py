"""
app.py — the free backend your mobile app talks to.

Run:  uvicorn app:app --host 0.0.0.0 --port 8000
Docs: open http://localhost:8000/docs to try every endpoint in the browser.

Flow:
  1. POST /documents            (upload 1+ page photos)  -> question packages
  2. GET  /documents/{id}/assets/{file}                  -> cropped diagrams
  3. PUT  /documents/{id}/questions/{qid}                -> teacher fixes text / pairing
  4. POST /documents/{id}/compile  (ticked question ids) -> .docx or .pdf
"""
from __future__ import annotations

import json
import os
import uuid
from pathlib import Path

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel

from export import compile_paper
from pairing import build_packages, to_json
from pipeline import PageAnalyzer

DATA = Path(os.getenv("DATA_DIR", "data"))
analyzer = PageAnalyzer(ocr_lang=os.getenv("OCR_LANG", "eng"),
                        device=os.getenv("DEVICE", "cpu"))
app = FastAPI(title="Question Paper Builder")


def _doc_dir(doc_id: str) -> Path:
    d = DATA / doc_id
    if not d.exists():
        raise HTTPException(404, "document not found")
    return d


def _load(doc_id: str) -> dict:
    return json.loads((_doc_dir(doc_id) / "questions.json").read_text("utf-8"))


@app.post("/documents")
async def create_document(pages: list[UploadFile] = File(...)):
    doc_id = uuid.uuid4().hex[:10]
    d = DATA / doc_id
    (d / "pages").mkdir(parents=True)
    page_objs = []
    for i, up in enumerate(pages, 1):
        path = d / "pages" / f"page{i}{Path(up.filename or '.jpg').suffix}"
        path.write_bytes(await up.read())
        page_objs.append(analyzer.analyze(path, i, d / "assets"))

    preamble, questions = build_packages(page_objs)
    data = to_json(preamble, questions)
    (d / "questions.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), "utf-8")
    return {"doc_id": doc_id, **data}


@app.get("/documents/{doc_id}")
def get_document(doc_id: str):
    return _load(doc_id)


@app.get("/documents/{doc_id}/assets/{name}")
def get_asset(doc_id: str, name: str):
    f = _doc_dir(doc_id) / "assets" / Path(name).name
    if not f.exists():
        raise HTTPException(404)
    return FileResponse(f)


@app.put("/documents/{doc_id}/questions/{qid}")
def update_question(doc_id: str, qid: str, question: dict):
    """The review screen sends back an edited question (fixed OCR, a diagram
    dragged to another question, etc.)."""
    data = _load(doc_id)
    for i, q in enumerate(data["questions"]):
        if q["id"] == qid:
            data["questions"][i] = {**q, **question, "id": qid, "needs_review": False}
            (_doc_dir(doc_id) / "questions.json").write_text(
                json.dumps(data, ensure_ascii=False, indent=2), "utf-8")
            return data["questions"][i]
    raise HTTPException(404, "question not found")


class CompileRequest(BaseModel):
    question_ids: list[str]
    format: str = "docx"          # docx | pdf
    title: str = "Question Paper"
    instructions: str = ""
    renumber: bool = True


@app.post("/documents/{doc_id}/compile")
def compile_document(doc_id: str, req: CompileRequest):
    d = _doc_dir(doc_id)
    if req.format not in ("docx", "pdf"):
        raise HTTPException(400, "format must be docx or pdf")
    data = _load(doc_id)
    known = {q["id"] for q in data["questions"]}
    unknown = [q for q in req.question_ids if q not in known]
    if not req.question_ids or unknown:
        raise HTTPException(400, f"unknown or empty question ids: {unknown}")
    out = d / f"paper_{uuid.uuid4().hex[:6]}.{req.format}"
    compile_paper(data, req.question_ids, d / "assets", out,
                  title=req.title, instructions=req.instructions, renumber=req.renumber)
    return FileResponse(out, filename=f"{req.title}.{req.format}")
