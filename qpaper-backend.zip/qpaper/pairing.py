"""
pairing.py — the "brain" that turns detected page blocks into Question packages.

Input : layout blocks for one or more pages (text / title / figure / formula /
        table / caption), each with a bounding box and its OCR text or LaTeX.
Output: a list of Questions, each carrying its own diagrams, formulas and
        tables, plus a confidence score and a human-readable reason for every
        pairing decision (so the app can ask the teacher to check weak ones).

It has no AI dependencies — it only reasons about geometry, reading order and
wording — so you can run `python pairing.py` to see it work on a mock page.
"""
from __future__ import annotations

import json
import re
from dataclasses import asdict, dataclass, field

# ----------------------------------------------------------------- data types

VISUAL_KINDS = {"figure", "formula", "table"}


@dataclass
class Block:
    kind: str                                  # text | title | figure | formula | table | caption
    bbox: tuple[float, float, float, float]    # x0, y0, x1, y1 in pixels
    text: str = ""                             # OCR text (or LaTeX for formulas)
    image: str | None = None                   # cropped PNG for figure/table/formula
    page: int = 1


@dataclass
class Page:
    number: int
    width: float
    height: float
    blocks: list[Block]


@dataclass
class Asset:
    kind: str                  # figure | formula | table
    image: str | None
    latex: str | None
    caption: str
    placement: str             # below | above | right
    confidence: float
    reason: str


@dataclass
class Question:
    id: str
    number: str
    text: str
    page: int
    parts: list[str] = field(default_factory=list)
    assets: list[Asset] = field(default_factory=list)
    needs_review: bool = False
    # internal: text boxes per page, used for the side-by-side test
    _boxes: dict = field(default_factory=dict, repr=False)


# ------------------------------------------------------------------- patterns

QUESTION_RE = re.compile(r"^\s*(?:Q(?:ues(?:tion)?)?\.?\s*)?(\d{1,3})\s*[.):]\s+\S", re.I)
SUBPART_RE = re.compile(r"^\s*\(?([a-h]|i{1,3}|iv|v|vi{0,3})\)\s+\S", re.I)
FIG_LABEL_RE = re.compile(r"\b(?:fig(?:ure)?|diagram|table)\.?\s*(\d+(?:\.\d+)?[a-z]?)", re.I)
# wording that points to a visual AFTER the question ...
POINTS_DOWN = re.compile(r"\b(below|following|shown|given|figure|diagram|graph|circuit|table)\b", re.I)
# ... or to a visual BEFORE the question
POINTS_UP = re.compile(r"\b(above|preceding|previous)\b", re.I)


# -------------------------------------------------------------- reading order

def _column(b: Block, mid: float) -> int:
    if b.bbox[2] <= mid * 1.05:
        return 0          # left column
    if b.bbox[0] >= mid * 0.95:
        return 1          # right column
    return -1             # spans both columns


def _is_two_column(blocks: list[Block], width: float) -> bool:
    mid = width / 2
    text = [b for b in blocks if b.kind in ("text", "title")]
    left = sum(_column(b, mid) == 0 for b in text)
    right = sum(_column(b, mid) == 1 for b in text)
    return left >= 2 and right >= 2


def reading_order(page: Page) -> list[Block]:
    """Order blocks the way a human reads: top-to-bottom, and for two-column
    pages, left column fully before right column (full-width items such as
    headings act as dividers between bands)."""
    blocks = page.blocks
    if not _is_two_column(blocks, page.width):
        row = max(page.height * 0.01, 10)   # tolerance so a row stays left→right
        return sorted(blocks, key=lambda b: (round(b.bbox[1] / row), b.bbox[0]))

    mid = page.width / 2
    ordered, band = [], []
    for b in sorted(blocks, key=lambda b: b.bbox[1]):
        if _column(b, mid) == -1:
            ordered += sorted(band, key=lambda x: (_column(x, mid), x.bbox[1]))
            band = []
            ordered.append(b)
        else:
            band.append(b)
    ordered += sorted(band, key=lambda x: (_column(x, mid), x.bbox[1]))
    return ordered


# ------------------------------------------------- split merged question text

def split_merged_questions(block: Block) -> list[Block]:
    """Layout models sometimes merge two short questions into one paragraph.
    If OCR lines show more than one question number, split the block and share
    its height among the pieces in proportion to their line counts."""
    if block.kind != "text":
        return [block]
    lines = [ln for ln in block.text.splitlines() if ln.strip()]
    starts = [i for i, ln in enumerate(lines) if QUESTION_RE.match(ln)]
    if len(starts) <= 1:
        return [block]
    if starts[0] != 0:
        starts = [0] + starts
    x0, y0, x1, y1 = block.bbox
    h = (y1 - y0) / max(len(lines), 1)
    pieces = []
    for a, b in zip(starts, starts[1:] + [len(lines)]):
        pieces.append(Block("text", (x0, y0 + a * h, x1, y0 + b * h),
                            "\n".join(lines[a:b]), page=block.page))
    return pieces


# ------------------------------------------------------------------- helpers

def _clean(t: str) -> str:
    return " ".join(t.split())


def _union(a, b):
    return (min(a[0], b[0]), min(a[1], b[1]), max(a[2], b[2]), max(a[3], b[3]))


def _side_by_side(q_box, v_box) -> bool:
    """Visual sits beside the question text: they overlap vertically by at
    least half of the shorter one, and do not overlap horizontally."""
    overlap = min(q_box[3], v_box[3]) - max(q_box[1], v_box[1])
    shorter = min(q_box[3] - q_box[1], v_box[3] - v_box[1])
    h_disjoint = q_box[2] <= v_box[0] or v_box[2] <= q_box[0]
    return h_disjoint and shorter > 0 and overlap / shorter >= 0.5


# --------------------------------------------------------------- main routine

def build_packages(pages: list[Page]) -> tuple[list[Asset], list[Question]]:
    """Returns (preamble_assets, questions)."""
    # 1. one stream of blocks in reading order, across all pages
    seq: list[Block] = []
    for page in sorted(pages, key=lambda p: p.number):
        for b in page.blocks:
            b.page = page.number
        expanded = [piece for b in page.blocks for piece in split_merged_questions(b)]
        seq += reading_order(Page(page.number, page.width, page.height, expanded))
    heights = {p.number: p.height for p in pages}

    # 2. walk the stream: start a question at every "4." / "Q4" anchor
    questions: list[Question] = []
    owner: list[int | None] = []          # question index "in force" at each block
    current: int | None = None
    for b in seq:
        if b.kind == "title":
            current = None                 # new section heading resets context
        elif b.kind == "text":
            m = QUESTION_RE.match(b.text)
            if m:
                body = re.sub(r"^\s*(?:Q(?:ues(?:tion)?)?\.?\s*)?\d{1,3}\s*[.):]\s*", "",
                              b.text, flags=re.I)
                questions.append(Question(id=f"q{len(questions) + 1:03d}",
                                          number=m.group(1), text=_clean(body),
                                          page=b.page))
                current = len(questions) - 1
                questions[current]._boxes[b.page] = b.bbox
            elif current is not None:
                q = questions[current]
                if SUBPART_RE.match(b.text):
                    q.parts.append(_clean(b.text))
                else:
                    q.text += " " + _clean(b.text)
                q._boxes[b.page] = _union(q._boxes.get(b.page, b.bbox), b.bbox)
        owner.append(current)

    # 3. attach captions to the nearest visual (just above, else just below)
    captions: dict[int, str] = {}
    for i, b in enumerate(seq):
        if b.kind != "caption":
            continue
        for j in (i - 1, i + 1):
            if 0 <= j < len(seq) and seq[j].kind in VISUAL_KINDS and seq[j].page == b.page:
                captions.setdefault(j, _clean(b.text))
                break

    # 4. decide an owner question for every visual
    preamble: list[Asset] = []
    for i, v in enumerate(seq):
        if v.kind not in VISUAL_KINDS:
            continue
        caption = captions.get(i, "")
        prev_q = owner[i]
        next_q = next((owner[j] for j in range(i + 1, len(seq))
                       if owner[j] is not None and owner[j] != prev_q
                       and seq[j].kind == "text"), None)
        target, placement, conf, reason = _decide(v, caption, prev_q, next_q,
                                                  questions, heights)
        asset = Asset(kind=v.kind, image=v.image,
                      latex=v.text if v.kind == "formula" else None,
                      caption=caption, placement=placement,
                      confidence=round(conf, 2), reason=reason)
        if target is None:
            preamble.append(asset)
        else:
            questions[target].assets.append(asset)
            if conf < 0.7:
                questions[target].needs_review = True
    return preamble, questions


def _decide(v, caption, prev_q, next_q, questions, heights):
    """Rules, strongest first. Returns (question_index, placement, confidence, reason)."""
    # Rule 1 — explicit label: caption "Fig. 4.4" and a question says "Fig. 4.4"
    m = FIG_LABEL_RE.search(caption)
    if m:
        label = m.group(1).lower()
        refs = [k for k, q in enumerate(questions)
                if any(x.group(1).lower() == label for x in FIG_LABEL_RE.finditer(q.text))]
        if refs:
            k = min(refs, key=lambda k: abs(k - (prev_q if prev_q is not None else k)))
            return k, "below", 0.95, f"caption '{caption}' is named in question {questions[k].number}"

    # Rule 2 — visual sits beside a question's text on the same page
    for k, q in enumerate(questions):
        box = q._boxes.get(v.page)
        if box and _side_by_side(box, v.bbox):
            return k, "right", 0.9, f"placed beside question {q.number} on the page"

    # Rule 3 — formulas belong to the question they appear inside
    if v.kind == "formula":
        if prev_q is not None:
            return prev_q, "below", 0.85, f"display formula inside question {questions[prev_q].number}"
        if next_q is not None:
            return next_q, "above", 0.6, "formula before the first question; check"
        return None, "below", 0.5, "formula outside any question"

    # Rule 4 — figure/table: compare the question before vs the one after
    if prev_q is None and next_q is None:
        return None, "below", 0.5, "no question on this page; kept as general material"
    if prev_q is None:
        return next_q, "above", 0.7, f"visual comes before question {questions[next_q].number}"

    p, n = questions[prev_q], (questions[next_q] if next_q is not None else None)
    p_points_down = bool(POINTS_DOWN.search(p.text))
    n_points_up = bool(n and POINTS_UP.search(n.text))

    if n_points_up and not re.search(r"\b(below|following)\b", p.text, re.I):
        return next_q, "above", 0.8, f"question {n.number} refers to a visual 'above'"
    if POINTS_UP.search(p.text) and not re.search(r"\b(below|following)\b", p.text, re.I):
        # wording contradicts position: the question talks about something "above"
        conf = 0.55
        why = (f"follows question {p.number}, but that question refers to a visual "
               f"'above' — please check")
    elif p_points_down:
        conf = 0.9
        why = f"question {p.number} mentions a figure/diagram and it follows directly"
    else:
        conf = 0.65
        why = f"nearest question before it is {p.number} (no wording confirms it)"
    # far-away visual → weaker evidence
    pbox = p._boxes.get(v.page)
    if pbox and (v.bbox[1] - pbox[3]) > 0.25 * heights.get(v.page, 1e9):
        conf -= 0.15
        why += "; large gap on the page"
    return prev_q, "below", conf, why


# ------------------------------------------------------------- serialisation

def to_json(preamble: list[Asset], questions: list[Question]) -> dict:
    qs = []
    for q in questions:
        d = asdict(q)
        d.pop("_boxes", None)
        qs.append(d)
    return {"preamble": [asdict(a) for a in preamble], "questions": qs}


# ---------------------------------------------------------------------- demo

def _demo_pages() -> list[Page]:
    """A mock single-column page and a mock two-column page."""
    p1 = Page(1, 1000, 1400, [
        Block("title", (50, 40, 950, 80), "Exercise 4.2"),
        Block("text", (60, 100, 940, 130), "3. State Newton's second law of motion."),
        Block("text", (60, 160, 940, 220), "4. A block of mass 2 kg rests on an inclined plane as shown "
                                           "in the figure below. Find the normal force."),
        Block("figure", (300, 230, 700, 480), image="p1_fig1.png"),
        Block("caption", (420, 485, 580, 505), "Fig. 4.1"),
        Block("text", (60, 540, 940, 570), "5. Calculate the kinetic energy using"),
        Block("formula", (380, 580, 620, 630), r"E_k = \frac{1}{2} m v^2", image="p1_eq1.png"),
        Block("text", (60, 670, 580, 700), "6. Identify the parts of this circuit."),
        Block("figure", (620, 650, 940, 820), image="p1_fig2.png"),
        Block("figure", (300, 860, 700, 1080), image="p1_fig3.png"),
        Block("caption", (420, 1085, 580, 1105), "Fig. 4.3"),
        Block("text", (60, 1130, 940, 1160), "7. Using the circuit above, find the current through R2."),
    ])
    p2 = Page(2, 1000, 1400, [
        Block("text", (40, 60, 480, 120), "8. Two resistors of 4 Ω and 6 Ω are joined in series. "
                                          "Find the equivalent resistance."),
        Block("text", (40, 140, 480, 180), "9. Draw the ray diagram for the lens in Fig. 4.4."),
        Block("text", (40, 200, 480, 260), "10. Define refraction.\n11. State Snell's law."),
        Block("figure", (540, 60, 960, 320), image="p2_fig1.png"),
        Block("caption", (680, 325, 820, 345), "Fig. 4.4"),
        Block("text", (520, 380, 960, 410), "12. Name the image formed by a plane mirror."),
        Block("text", (520, 430, 960, 470), "13. Find the power of a lens of focal length 0.5 m."),
    ])
    return [p1, p2]


if __name__ == "__main__":
    pre, qs = build_packages(_demo_pages())
    for q in qs:
        flag = "  ⚠ review" if q.needs_review else ""
        print(f"Q{q.number}: {q.text}{flag}")
        for a in q.assets:
            what = a.latex or a.image
            print(f"    └─ {a.kind:7} {what}  [{a.placement}, {a.confidence}]  ← {a.reason}")
    if pre:
        print("Unassigned:", [a.image for a in pre])
