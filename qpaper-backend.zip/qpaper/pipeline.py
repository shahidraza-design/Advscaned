"""
pipeline.py — turns a page photo into layout Blocks for pairing.py.

Free, open-source models used:
  * DocLayout-YOLO  — finds titles, text, figures, tables, formulas, captions
  * Tesseract OCR   — reads text (install language packs: eng, hin, ben, urd ...)
  * pix2tex         — turns a cropped formula image into LaTeX

Each model loads lazily, so the server starts fast and you can swap any one
of them later (e.g. PaddleOCR PP-StructureV3 or MinerU for harder pages)
without touching pairing.py — they only need to return Blocks.
"""
from __future__ import annotations

from pathlib import Path

from PIL import Image

from pairing import Block, Page

# DocLayout-YOLO class name -> our block kind (None = ignore, e.g. page numbers)
LABEL_MAP = {
    "title": "title",
    "plain text": "text",
    "figure": "figure",
    "figure_caption": "caption",
    "table": "table",
    "table_caption": "caption",
    "table_footnote": "text",
    "isolate_formula": "formula",
    "formula_caption": "caption",
    "abandon": None,           # headers, footers, page numbers
}


class PageAnalyzer:
    def __init__(self, ocr_lang: str = "eng", device: str = "cpu", min_conf: float = 0.25):
        self.ocr_lang = ocr_lang      # e.g. "eng+hin" or "eng+ben"
        self.device = device          # "cuda:0" if you have a GPU
        self.min_conf = min_conf
        self._layout = None
        self._latex = None

    # ---------------------------------------------------------------- models
    def layout_model(self):
        if self._layout is None:
            from doclayout_yolo import YOLOv10
            from huggingface_hub import hf_hub_download
            weights = hf_hub_download(
                repo_id="juliozhao/DocLayout-YOLO-DocStructBench",
                filename="doclayout_yolo_docstructbench_imgsz1024.pt")
            self._layout = YOLOv10(weights)
        return self._layout

    def latex_model(self):
        if self._latex is None:
            from pix2tex.cli import LatexOCR
            self._latex = LatexOCR()
        return self._latex

    def ocr(self, img: Image.Image) -> str:
        import pytesseract
        # psm 6 = treat crop as one block of text; keep line breaks for splitting
        return pytesseract.image_to_string(img, lang=self.ocr_lang, config="--psm 6").strip()

    # ---------------------------------------------------------------- main
    def analyze(self, image_path: str | Path, page_no: int, asset_dir: str | Path) -> Page:
        image_path, asset_dir = Path(image_path), Path(asset_dir)
        asset_dir.mkdir(parents=True, exist_ok=True)
        img = Image.open(image_path).convert("RGB")
        W, H = img.size

        result = self.layout_model().predict(str(image_path), imgsz=1024,
                                             conf=self.min_conf, device=self.device)[0]
        names = result.names
        blocks: list[Block] = []
        for n, (box, cls) in enumerate(zip(result.boxes.xyxy.tolist(),
                                           result.boxes.cls.tolist())):
            kind = LABEL_MAP.get(names[int(cls)])
            if kind is None:
                continue
            x0, y0, x1, y1 = box
            pad = 6 if kind in ("figure", "table") else 2
            crop_box = (max(0, x0 - pad), max(0, y0 - pad), min(W, x1 + pad), min(H, y1 + pad))
            crop = img.crop(crop_box)

            block = Block(kind=kind, bbox=(x0, y0, x1, y1), page=page_no)
            if kind in ("text", "title", "caption"):
                block.text = self.ocr(crop)
                if not block.text:
                    continue
            else:
                # keep the original pixels: diagrams stay sharp in the output
                name = f"p{page_no}_{kind}{n}.png"
                crop.save(asset_dir / name)
                block.image = name
                if kind == "formula":
                    try:
                        block.text = self.latex_model()(crop)
                    except Exception:
                        block.text = ""     # fall back to the image of the formula
            blocks.append(block)
        return Page(number=page_no, width=W, height=H, blocks=blocks)
